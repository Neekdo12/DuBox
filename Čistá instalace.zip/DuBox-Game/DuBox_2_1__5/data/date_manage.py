#import modulu
'''
import csv
import random
from command import *
import datetime
'''
def datemanagee(pause, cls, csv, random):
    import csv
    end = 0
    #zaklad celeho programu - nacteni nazvu pozic
    while True:
        if end == 1:
            pocet = len(row)
            
            #ulozeni pozic
            with open('DuBox_2_1__5/data/files.csv', mode='w') as employee_file:
                employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                #print (row)  
                for i in row:
                    employee_writer.writerow(row)
                    #print(i)
                break
            
            
        with open('DuBox_2_1__5/data/files.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            
            for row in csv_reader:
                pass
        while True:
            if end == 1:
                break
            while True:
                
                
                #obrazovka co vydi hrac
                cls(1)
                print ('toto je list pozic: ')
                print (row)
                print('new - nova pozice')
                print ('del - smazat nejakou pozici')
                print ('jmeno pozice pro nacteni pozice')
                akce = input()
                
                #zjisteni rozhodnuti hrace
                if akce == 'new':
                    cls(1)
                    print ('napis nazev nove pozive\nnesmi se opakova!')
                    akce = input()
                    test = row.count(akce)
                    if test == 0:
                        cls(1)
                        print ('pozice byla vytvorena')
                        row.append(akce)
                        with open('DuBox_2_1__5/data/position/' + akce, mode='w') as employee_file:
                            employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                            
                            employee_writer.writerow([str(0), str(0), str(500), str(1), str(0), str(0), str(15), str(50),str(100), str(1), str(0), str(10), str(10), str(10), str(1), str(0), str(0), str(5), str(0), str(random.randint(0, 1000000)), str(1), str(0)])
                        pause()
                    else:
                        cls(1)
                        print('bouhzel tato pozice jis existuje ale pokud ji chces vytvorit tak muzes smazat starou')
                        pause()
                elif akce == 'del':
                    cls(1)
                    print ('napis nazev pozice')
                    akce = input()
                    
                    test = row.count(akce)
                    if test >= 1:
                        cls(1)
                        print('pozice byla smazana')
                        pause()
                        row.remove(akce)
                        break
                      #  print(row)
                        #pause()
                    else:
                        cls(1)
                        print('ale pozice nejdriv musi byt vytvorena')
                        pause()
                        break
                elif akce == 'konec':
                    end = 1
                    break
                temp = row.count(akce)
                if temp == 0:
                    cls(1)
                    print ('tato pozice neexistuje')
                    pause()
                elif temp == 1:
                    cls(1)
                    print ('tato pozice byla prirazena jako hratelna')
                    pause()
                    with open('DuBox_2_1__5/data/position.txt', 'w' ) as temp1:
                        temp1.write(akce)
                        
                        
            
         
            
            
        