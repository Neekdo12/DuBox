import datetime
import time

def cls(clear):
    if clear == 1:
        print("\033[H\033[J", end="")
    else:
        print ('cls')
def timeout(second):
    if second == 'pause':
        konec = input()
    else:
        time.sleep(second)
def pause():
    konec = input()
def armor(temp):
    return temp%10 == 0
def pdi(temp):
    if temp == 1:
        breakpoint()