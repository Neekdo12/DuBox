import csv
names = []

with open('files.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            line_count += 1
row[0] = int(row[0])

if row[0] == 0:
    print('ted spolu vytvorime tvou prvni pozici')
    print ('napis svoje jmeno a vek')
    name = input('jmeno: ')
    age = input('vek: ')
    #names.adition = names

else:
    print ('zadej nazev pozice')
    print ('nebo new pro vytvoreni nove a del pro smazani nejake pozice')
    print('bez (.csv)')
    print ('seznam:')
    
    
    x = 1
    for rows in range(0, 10001):
        print (row[x])
        x += 1
        row[0] -= 1
        if row[0] == 0:
            break
    name = input()
    with open('position.txt', 'w') as temp:
        temp.write(name)
    

name = name+'.csv'


with open(name, mode='w') as employee_file:
    employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

    employee_writer.writerow([str('1'), str('0'), str('500'), str('1'), str('0'), str('0'), str('15'), str('50'),str('100'), str('1'), str(0), str(10), str(10), str(10), str(1), str(0), str(0), str(5), str(0)])
    
with open('files.csv', mode='w') as employee_file:
    employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

    employee_writer.writerow([str(1), name])






