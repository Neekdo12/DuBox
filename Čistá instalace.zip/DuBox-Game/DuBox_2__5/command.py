import datetime
import time

def cls():
    print("\033[H\033[J", end="")
def timeout(second):
    if second == 'pause':
        konec = input()
    else:
        time.sleep(second)
def pause():
    konec = input()
def armor(temp):
    return temp%10 == 0