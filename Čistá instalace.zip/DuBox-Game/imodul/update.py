from imodul.command import *
import csv
import random
with open('ver_run.txt', 'r') as file:
    ver = file.readlines()
    #print(ver)
    ver = ver[0]
c = 1
    #uvodni text
text(f'Vyta te instalator DuBoxu verze {ver}')
text('prosim kdo nerozumi pythonu prectite si tutorial v DuBoxu\npokud nemate nainszalovany DuBox tutorial se take nachazi v readme.txt')
cls(c)
    #seznam akci
while True:
    print('obnoveni - obnovi data do stavu po instalaci (doporucuji nejdrave udelat zalohu)')#\nzaloha - soubor se zalohou DuBoxu\nnahraz zalohu - nahraje zalohu do DuBoxu\nvytvoreni aktualizacniho souboru - vytvori soubor ktery nahrajete do nove verze DuBoxu\n verze - zobrazi kompatybilni verze s kterymi lze tuto verzi aktualizovat')
    akce = input()
    
    if akce == 'obnoveni':
        cls(c)
        if ver == 'dva_dva__pet':
            with open('dubox_2_2__5/data/position.txt', 'w') as file:
                file.write('tester')
            with open('firs_instal_data', 'w') as file:
                file.write('0')
                
                
                
            with open('dubox_2_2__5/data/position/tester' , mode='w') as employee_file:
                employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                            
                employee_writer.writerow([str(1), str(0), str(500), str(1), str(0), str(0), str(15), str(50),str(100), str(1), str(0), str(10), str(10), str(10), str(1), str(0), str(0), str(5), str(0), str(random.randint(0, 1000000)), str(1), str(0), str('2.2..5')])
                
            with open('dubox_2_2__5/data/files.csv', mode='w') as employee_file:
                            employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                            
                            employee_writer.writerow('tester')
            
        
        for row in range(1, 16):
            print('.' * row)
            timeout(1)
            cls(c)
        break
        '''
        #vytvoreni zalohy
    elif akce == 'zaloha':
        
        #zjisteni dat pro vytvoreni zalohy
        with open('data/files.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            
            for row in csv_reader:
                pass
                
        #nacteni dat z jednotlivych pozic
        with open('data/files.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            
            for rows in csv_reader:
                pass
        '''
        
                
    