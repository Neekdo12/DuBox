def instal(pause, cls, c, text, timeout):
    while True:
        cls(c)
        print ('prosim vyber si verzi:')
        print ('2.2..5 (doporucene)\n2.1..5\n2..5\n1.1.1..5\n1.1..5\n1.0.1..5\n1.0..5')
        akce = input()
        
        if akce == '2.2..5':
            #instalace 2.2..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('dva_dva__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
            break
        elif akce == '2.1..5':
            #instalace 2.1..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('dva_jedna__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
            break
        elif akce  == '2..5':
            #instalace 2..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('dva__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
            break
        elif akce == '1.1.1..5':
            #instalace 1.1.1..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('jedna_jedna_jedna__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
        elif akce == '1.1..5':
            #instalace 1.1..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('jedna_jedna__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
            break
        elif akce == '1.0.1..5':
            #instalace 1.0.1..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('jedna_nula_jedna__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
            break
        elif akce == '1.0..5':
            #instalace 1.0..5 verze
            with open('ver_run.txt', 'w') as file:
                file.write('jedna_nula__pet')
            with open('firs_instal_data.txt', 'w') as file:
                file.write('1')
            break
        else:
            print('tak di vyber spravne')
            input()
            
            