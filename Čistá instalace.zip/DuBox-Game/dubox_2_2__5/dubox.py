def dubox(csv, cls, pdi, timeout,  text, random, learnig, tutoriall, pause, datemanagee, change_log, development):    
    tryce = 1
    if tryce == 1:
        #try:
        for row in [1]:
            '''
            from data.modul.date_manage import *
            import csv
            from data.modul.command import *
            import datetime
            from data.modul.development import *
            import random
            from data.modul.tutorial import *
            from data.modul.change_log import *
            from data.modul.update import *
            from data.info.ver import ver
            '''
            
            
            with open('dubox_2_2__5/data/position.txt', 'r') as temp:
                temp1 = temp.readlines()
                temp1 = temp1[0]
            
                
    
            
            
            
            
            
            with open('dubox_2_2__5/data/position/' + temp1) as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                line_count = 0
                for row in csv_reader:
                    pass
                        
            if str(row[17]) == 'pause':
                data = {
                    'tutorial': int(row[0]),
                    'change_log': int(row[1]),
                    'penize': int(row[2]),
                    'vm': int(row[3]),
                    'vs': int(row[4]),
                    'rhp': int(row[5]),
                    'yhp': int(row[6]),
                    'cenam': int(row[7]),
                    'cenas': int(row[8]),
                    'mistnost': int(row[9]),
                    'deflect': int(row[10]),
                    'cenah': int(row[11]),
                    'cenab': int(row[12]),
                    'cenak': int(row[13]),
                    'vh': int(row[14]),
                    'vb': int(row[15]),
                    'vk': int(row[16]),
                    'hledat': [1, 0, 0, 0, 0, 0, 0],
                    'endp': 0,
                    'end': 0,
                    'second': row[17],
                    'devel': row[18],
                    'akce': 1,
                    'pasword': row[19],
                    'clear': int(row[20]),
                    'pdi': int(row[21]),
                    'ver': row[22]
                    
                    
                }
            else:
                    data = {
                    'tutorial': int(row[0]),
                    #'tutorial': 0,
                    'change_log': int(row[1]),
                    'penize': int(row[2]),
                    'vm': int(row[3]),
                    'vs': int(row[4]),
                    'rhp': int(row[5]),
                    'yhp': int(row[6]),
                    'cenam': int(row[7]),
                    'cenas': int(row[8]),
                    'mistnost': int(row[9]),
                    'deflect': int(row[10]),
                    'cenah': int(row[11]),
                    'cenab': int(row[12]),
                    'cenak': int(row[13]),
                    'vh': int(row[14]),
                    'vb': int(row[15]),
                    'vk': int(row[16]),
                    'hledat': [1, 0, 0, 0, 0, 0, 0],
                    'endp': 0,
                    'end': 0,
                    'second': int(row[17]),
                    'devel': int(row[18]),
                    'akce': 1,
                    'pasword': row[19],
                    'clear': int(row[20]),
                    'pdi': int(row[21]),
                    'ver': row[22]
                    
                    
                }
            
            
            
            #print (data)
            #timeout(data['second'])
            
            if data['tutorial'] == 1:
                data = tutoriall(data, pause, timeout, cls, random, learnig, text)
            
            while 1 == 1:
                if data['endp'] == 1:
                    return 1
                elif data['endp'] == 2:
                    return 0
                    update(pause, cls, data, ver, text)
                if data['change_log'] == 0:
                    data = change_log(pause, cls, data)
                    
                    
                    
                    
                    
                while data['hledat'][0] == 1:
                    cls(data['clear'])
                    pdi(data['pdi'])
                    print ('napis akci kterou chces provest')
                    print ('nebo napis napoveda pro zobrazeni napovedy')
                    if data['akce'] == 1:
                        akce = input()
                    if akce == 'obchod':
                        data['hledat'][0] = 0
                        data['hledat'][1] = 'obchod'
                    elif akce == 'inventar':
                        data['hledat'][2] = 'inventar'
                        data['hledat'][0] = 0
                    elif akce == 'napoveda':
                        data['hledat'][0] = 0
                        data['hledat'][3] = 'napoveda'
                    elif akce == 'dalsi':
                        data['hledat'][0] = 0
                        data['hledat'][4] = 'mapa'
                        data['hledat'][5] = 1
                    elif akce == 'zpet':
                        data['hledat'][0] = 0
                        data['hledat'][4] = 'mapa'
                        data['hledat'][5] = 2
                    elif akce == 'prohledat':
                        data['hledat'][0] = 0
                        data['hledat'][4] = 'mapa'
                        data['hledat'][5] = 3
                    elif akce == 'mistnost':
                        print (data['mistnost'])
                        timeout(data['second'])
                    elif akce == 'nastaveni':
                        data['hledat'][0] = 0
                        data['hledat'][6] = 1
                    elif akce == 'konec':
                        
                        with open('dubox_2_2__5/data/position/' + temp1, mode='w') as employee_file:
                            employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            
                            employee_writer.writerow([str(data['tutorial']), str(data['change_log']), str(data['penize']), str(data['vm']), str(data['vs']), str(data['rhp']), str(data['yhp']), str(data['cenam']), str(data['cenas']), str(data['mistnost']), str(data['deflect']), str(data['cenah']), str(data['cenab']), str(data['cenak']), str(data['vh']), str(data['vb']), str(data['vk']), str(data['second']), str(data['devel']), str(data['pasword']), str(data['clear']), str(data['pdi']), str(data['ver'])])
                        
                        
                        
                        
                            data['endp'] = 1
                            data['hledat'][0] = 0
                            inventar = 1
                            
                            break
                    elif akce == 'error':
                        temp = 0/0
                    
                    elif akce == 'development':
                        if data['devel'] == '1':
                            data = development(data, pause, timeout, cls, temp1)
                    
                        else:
                            print('je potreba ho nejdrive zapnout v nastaveni')
                            timeout(data['second'])
                    elif akce == 'check_data_devel':
                        cls(data['clear'])
                        print (data)
                        pause()
                    elif akce == 'data manage':
                        datemanagee(pause, cls, csv, random)
                        akce = 'konec'
                        data['hledat'][0] = 1
                        data['akce'] = 0
                    elif akce == 'verze':
                        print(data['ver'])
                        pause()
                    elif akce == 'update':
                        with open('dubox_2_2__5/data/position/' + temp1, mode='w') as employee_file:
                            employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            
                            employee_writer.writerow([str(data['tutorial']), str(data['change_log']), str(data['penize']), str(data['vm']), str(data['vs']), str(data['rhp']), str(data['yhp']), str(data['cenam']), str(data['cenas']), str(data['mistnost']), str(data['deflect']), str(data['cenah']), str(data['cenab']), str(data['cenak']), str(data['vh']), str(data['vb']), str(data['vk']), str(data['second']), str(data['devel']), str(data['pasword']), str(data['clear']), str(data['pdi']), str(data['ver'])])
                        
                        
                        
                        
                            data['endp'] = 2
                            data['hledat'][0] = 0
                        
                    else:
                        print ('chybny text')
                        timeout(data['second'])
                        
                        #obchod
                        
                    while data['hledat'][1] == 'obchod':
                        
                        #zeptani se na akci
                        
                        otazka = 1
                        cls(data['clear'])
                        print ('napis co chces provest v obchode')
                        print ('nebo napoveda pro zobrazeni napovedy')
                        akce = input()
                        
                        #kod ktery zapne kod ktery jste si vybrali
                        
                        if akce == 'seznam':
                            
                            #vypise co se da koupit a cenu
                            
                            cls(data['clear'])
                            print ('vylepseni mece - ' + str(data['cenam']) + ' modraj')
                            
                            
                            print('')
                            print ('vylepseni stitu - ' + str(data['cenas']) + ' modraj')
                            print ()
                            print ('vylepseni helmi - ' + str(data['cenah']) + ' modraj')
                            print ()
                            print ('vylepseni brneni - ' + str(data['cenab']) + ' modraj')
                            print ()
                            print ('vylepseni kalhot - ' + str(data['cenak']) + ' modraj')
                            
                            print ('')
                            print ('dozdravit - 5 modraj')
                            print ()
                            print ('zivot - 50 modraj')
                            print()
                            print ('pokud chcez zjistit co jake vylepseni dela napis podrobnosti a v \ndalsim textovem poli nazev vylepseni')
                            akce = input() 
                            if akce == 'podrobnosti':
                                akce = input()
                                if akce == 'vylepseni mece':
                                    cls(data['clear'])
                                    print ('z kazdym jedni levelem se zvisi poskozeni zbrani s nazvem mec')
                                    
                                    timeout(data['second'])
                                elif akce == 'vylepseni stitu':
                                    cls(data['clear'])
                                    print ('kazdy jeden level prida sanci 2% na vyhnuti se utoku priser. maximalni procento je 50')
                                    timeout(data['second'])
                                elif akce == 'dozdravit':
                                    cls(data['clear'])
                                    print ('dozdracu tve zivoty')
                                    timeout(data['second'])
                                elif akce == 'zivot':
                                    cls(data['clear'])
                                    print ('da ti 15 zivotu na vic a dozdravi te')
                                elif akce == 'vylepseni helmi':
                                    cls(data['clear'])
                                    print ('kazd jeden leve prida damage reducion o 0,1 tedy kazdy desaty level bude redukovat damage o 1')
                                elif akce == 'vylepseni brneni':
                                    cls(data['clear'])
                                    print ('kazd jeden leve prida damage reducion o 0,1 tedy kazdy desaty level bude redukovat damage o 1')
                                elif akce == 'vylepseni kalhot':
                                    cls(data['clear'])
                                    print ('kazd jeden leve prida damage reducion o 0,1 tedy kazdy desaty level bude redukovat damage o 1')
                                    
                                    timeout(data['second'])
                                else:
                                    print ('cybny text')
                                    timeout(data['second'])
                                
                                
                        elif akce == 'nakup':
                            
                            #zepta se na to co chcete koupit
                            
                            cls(data['clear'])
                            print ('co chcete koupit?\nnebo napis seznam pro zobrazeni seznamu pri nakupovani')
                            nakup = input()
                            
                            if nakup == 'seznam':
                            
                            #vypise co se da koupit a cenu
                            
                                cls(data['clear'])
                                print ('vylepseni mece - ' + str(data['cenam']) + ' modraj')
                            
                            
                                print('')
                                print ('vylepseni stitu - ' + str(data['cenas']) + ' modraj')
                            
                            
                                
                                print()
                                print ('vylepseni helmi - ' + str(data['cenah']) + ' modraj')
                                print ()
                                print ('vylepseni brneni - ' + str(data['cenab']) + ' modraj')
                                print ()
                                print ('vylepseni kalhot - ' + str(data['cenak']) + ' modraj')
                                
                                print ('')
                                print ('dozdravit - 5 modraj')
                                print ()
                                print ('zivot - 50 modraj')
                                
                                
                                timeout(data['second'])
                                print ()
                                print ()
                                print ('co chcete koupit?')
                                nakup = input()
                            
                            #koupi vase zadane vylepseni
                            
                            if nakup == 'vylepseni mece':
                                if int(data['penize']) >= data['cenam']:
                                    
                                    #zkonrroluke jestli mate dostatek penez a pricte silu mece
                                    
                                    temp = int(data['penize'])
                                    temp -= data['cenam']
                                    
                                    data['penize'] = temp
                                    data['vm'] = data['vm'] + 1
                                    data['cenam'] = data['cenam'] * 2
                                    cls(data['clear'])
                                    print ('vylepseni koupeno')
                                    timeout(data['second'])
                                    
                                    
                                    
                            elif nakup == 'vylepseni stitu':
                                if data['penize'] >= data['cenas']:
                                    data['penize'] = int(data['penize']) - data['cenas']
                                    cls(data['clear'])
                                    print ('vylepseni koupeno')
                                    data['vs'] = data['vs'] + 1
                                    timeout(data['second'])
                                else:
                                    cls(data['clear'])
                                    print ('nedostatek penez')
                                    timeout(data['second'])
                                    
                            elif nakup == 'dozdravit':
                                if int(data['penize']) >= 5:
                                    data['penize'] = int(data['penize']) - 1
                                    cls(data['clear'])
                                    print ('byl jsi dozdraven')
                                    data['yhp'] = data['yhp']+data['rhp']
                                    data['rhp'] = 0
                                    timeout(data['second'])
                                    
                                else:
                                    cls(data['clear'])
                                    print ('nedostatek penez')
                                    timeout(data['second'])
                                    
                            elif nakup == 'zivot':
                                if int(data['penize']) >= 50:
                                    data['penize'] = int(data['penize']) - 50
                                    cls(data['clear'])
                                    print ('srdce koupeno')
                                    data['yhp'] = data['yhp']+data['rhp']+15
                                    data['rhp'] = 0
                                    timeout(data['second'])
                                        
                                        
                                    
                                    
                                    #vypsani nedostatku penez a chyba v napsanem textu
                                    
                                else:
                                    cls(data['clear'])
                                    print ('nedostatek penez')
                                    timeout(data['second'])
                                        
                                        
                                    
                                    
                                    #vypsani nedostatku penez a chyba v napsanem 
                                
                                
                            elif nakup == 'vylepseni helmi':
                                if int(data['penize']) >= data['cenah']:
                                    data['penize'] = int(data['penize']) - data['cenah']
                                    cls(data['clear'])
                                    print ('helma vylepsena')
                                    data['vh'] = data['vh']+1
                                    data['rhp'] = 0
                                    timeout(data['second'])
                                else:
                                    cls(data['clear'])
                                    print ('nedostatek penez')
                                    timeout(data['second'])
                                
                                
                            elif nakup == 'vylepseni brneni':
                                if int(data['penize']) >= data['cenab']:
                                    data['penize'] = int(data['penize']) - data['cenab']
                                    cls(data['clear'])
                                    print ('brneni vylepseno')
                                    data['vb'] = data['vb']+1
                                    data['rhp'] = 0
                                    timeout(data['second'])
                                    
                                else:
                                    cls(data['clear'])
                                    print ('nedostatek penez')
                                    timeout(data['second'])
                                
                                
                            elif nakup == 'vylepseni kalhot':
                                if int(data['penize']) >= data['cenak']:
                                    data['penize'] = int(data['penize']) - data['cenak']
                                    cls(data['clear'])
                                    print ('kalhoty vylepseny')
                                    data['vk'] = data['vk']+1
                                    data['rhp'] = 0
                                    timeout(data['second'])
                                        
                                        
                                    
                                    
                                    #vypsani nedostatku penez a chyba v napsanem textu
                                    
                                else:
                                    cls(data['clear'])
                                    print ('nedostatek penez')
                                    timeout(data['second'])
                            
                            else:
                                cls(data['clear'])
                                print ('toto vylepseni neexistuje')
                                timeout(data['second'])
                        elif akce == 'penezenka':
                            cls(data['clear'])
                            print (int(data['penize']))
                            timeout(data['second'])
                        elif akce == 'konec':
                            data['hledat'][0] = 1
                            data['hledat'][1] = 0
                            
                        else:
                            cls(data['clear'])
                            print ('cybny text')
                            timeout(data['second'])
                    while data['hledat'][2] == 'inventar':
                        
                        #inventar
                        
                        cls(data['clear'])
                        print (data['vm'])
                        print ('sila mece')
                        print ('')
                        print (data['vs'])
                        print ('sila stitu')
                        print ('')
                        print (int(data['penize']))
                        print ('penize')
                        print ()
                        print (data['yhp'])
                        print ('zivoty')
                        print()
                        print (data['vh']-1)
                        print('helma')
                        print()
                        print(data['vb'])
                        print('brneni')
                        print()
                        print(data['vk'])
                        print('kalhoty')
                        timeout(data['second'])
                        
                        data['hledat'][2] = 0
                        data['hledat'][0] = 1
                        break
                    cls(data['clear'])
                    while data['hledat'][3] == 'napoveda':
                        print ('dalsi - dalsi mistnost')
                        print ('zpet - predhozi mistnost')
                        print ('prohledat - pro prohledani mistnoati')
                        print ('obchod - otevreni obchodu')
                        print ('inventar - pro otevreni inventare')
                        print ('seznam - pro otevreni nakupniho seznamu (pouze v obchode)')
                        print ('penezenka - pro zobrazeni tvich penez (pouze v obchode)')
                        print ('nakup - proved nakup (pouze v obchode)')
                        print ('konec - pro vraceni do hry a pokud uz vni jste tak ukonci a vypne hru')
                        print('mistnost - zobrazi mistnost ve ktere se nachazis')
                        print ('nastaveni - otevre nastaveni')
                        print ('tutorial - pokud jsi v napovede spusti tutorial')
                        akce = input()
                        if akce == 'tutorial':
                            data = tutoriall(data, pause, timeout, cls, random, learnig, text)
                        data['hledat'][0] = 1
                        data['hledat'][3] =0
                        
                        
                    while data['hledat'][6] == 1:
                        
                        cls(data['clear'])
                        #vypsani uvodniho textu
                        print('cekaci doba - nastav si jak dlouho chces cekat pred smazanim funkcniho textu\nerror - vyhodi error nelze delit nulou\nvyvojarsky rezim - zapne vyvojarsky rezim(je potreba znat heslo)\nkonec - pro vraceni do hry\npause - cekaci dobu zmeni na pokracovani pomoci enteru')
                        akce = input()
                        if akce == 'cekaci doba':
                            #nastaveni cekaci doby
                            cls(data['clear'])
                            print ('napis jak dlouho chces cekat')
                            print ('je potreba napsat cele cislo jinak program vyhodi error!!')
                            temp = input()
                            data['second'] = int(temp)
                            #ukonceni nastaveni
                        elif akce == 'konec':
                            data['hledat'][6] = 0
                            data['hledat'][0] = 1
                            #vyhozeni erroru  nelze delit nulou
                        elif akce == 'error':
                            temp = 0/0
                        elif akce == 'vyvojarsky rezim':
                            #napis heslo
                            
                            cls(data['clear'])
                            print ('napis helso')
                            pasword = input()
                            
                            #tesstovani hesla
                            if pasword == data['pasword']:
                                
                                if data['devel'] == 1:
                                    #vypnuti vyvojarskeho rezimu
                                    print ('vyvojarsky rezim vypnut')
                                    pause()
                                    
                                    data['devel'] = 0
                                    akce = 'konec'
                                    data['hledat'][0] = 1
                                    data['akce'] = 0
                                    break
                                else:
                                    #pridani starusu devel
                                    print('hra se restartuje a po napsani prikazu development se dostanete k funkcim pro vyvojare\n pokud chcete tento mod vypnout tak v nastavine znovu zadejte helso nebo uloz hru prez polozku data ve vyvojarkem nastaveni')
                                    timeout(data['second'])
                                    data['devel'] = 1
                                    data['akce'] = 0
                                    akce = 'konec'
                                    data['hledat'][0] = 1
                                    break
                                    
                                    
                                    
                            #spatme heslo
                            else:
                                print('chybne helso')
                                timeout(data['second'])
                        elif akce == 'pause':
                            if data['second'] == 'pause':
                                data['second'] = 0
                                print ('pause vypnut\nnapis pocet vterin')
                                akce = input()
                                data['second'] = int(akce)
                                timeout(data['second'])
                            else:
                                data['second'] = 'pause'
                                print ('pause zapnuto')
                                timeout(data['second'])
                                
                
                    
                while data['hledat'][4] == 'mapa':
                    while data['hledat'][5] == 1:
                        data['mistnost'] = data['mistnost']+1
                        if data['mistnost'] == 6:
                            print ('konecna mistnost')
                            timeout(data['second'])
                            data['mistnost'] = data['mistnost']-1
                        data['hledat'][5] = 0
                        data['hledat'][4] = 0
                        data['hledat'][0] = 1
                        cls(data['clear'])
                    
                    while data['hledat'][5] == 2:
                        data['mistnost'] = data['mistnost']-1
                        if data['mistnost'] == 0:
                            print ('jsi na zacatku')
                            timeout(data['second'])
                            data['mistnost'] = data['mistnost']+1
                        data['hledat'][5] = 0
                        data['hledat'][4] = 0
                        data['hledat'][0] = 1
                        cls(data['clear'])
                    cls(data['clear'])
                    
                    while data['hledat'][5] == 3:
                        pocet = 0
                        end = 0
                        if data['mistnost'] == 1:
                            cls(data['clear'])
                            print ('v mistnosti se nachazi 1 bedna')
                            print ('co chces provest -')
                            print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                            print ('otevrit - otevrit truhlu')
                            print ('chodba - jit do tajne chodby')
                            makce = input()
                            if makce == 'boj':
                                print ('v mistnosti se nenachazi prisery')
                                
                                #bojd = [1, 1, 15, 'mys', 5]
                            elif makce == 'otevrit':
                                cls(data['clear'])
                                print ('v bedne se nachazi elixir zivot')
                                timeout(data['second'])
                                cls(data['clear'])
                                print ('najedno sis vsiml ze nemas srdce a ze se take zmenilo v krabici nastesti si na posledni chvili stihl vypit lektvar zivota a veskere rany magii utrpene se zacelili.')
                                timeout(data['second'])
                            elif makce == 'chodba':
                                print ('zde neni zadna tajna chodba')
                                timeout(data['second'])
                            elif makce == 'konec':
                                data['hledat'][4] = 0
                                data['hledat'][5] = 0
                                data['hledat'][0] = 1
                                break
                            else:
                                print ('uz zase?')
                                timeout(data['second'])
                        elif data['mistnost'] == 2:
                            print ('v mistnosti je 1 prisera')
                            print ('co chces provest -')
                            print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                            print ('otevrit - otevrit truhlu')
                            print ('chodba - jit do tajne chodby')
                            makce = input()
                            if makce == 'boj':
                                print ('')
                                
                                bojd = [1, 1, 15, 'mys', 5]
                                data['hledat'][5] = 4
                            elif makce == 'otevrit':
                                print ('zde neni zadna bedna ale treba jinde bude')
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'chodba':
                                print ('je zde jen otvor zasipany suti')
                                #int(data['penize']) = int(data['penize'])+
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'konec':
                                data['hledat'][4] = 0
                                data['hledat'][5] = 0
                                data['hledat'][0] = 1
                                break
                            else:
                                print ('uz zase?')
                                timeout(data['second'])
                                cls(data['clear'])
                        elif data['mistnost'] == 3:
                            print ('je tady je ve stene dira a vni se neco leskne. jestli pak to nebude tajna hodba!')
                            print ('co chces provest -')
                            print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                            print ('otevrit - otevrit truhlu')
                            print ('chodba - jit do tajne chodby')
                            makce = input()
                            if makce == 'boj':
                                print ('')
                                
                                #bojd = [1, 1, 15, 'mys', 5]
                            elif makce == 'otevrit':
                                print ('neni to bedna ale chodba')
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'chodba':
                                print ('jej nasel jsi 50 modraj ted si muzes neco koupit')
                                data['penize'] = int(data['penize'])+50
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'konec':
                                data['hledat'][4] = 0
                                data['hledat'][5] = 0
                                data['hledat'][0] = 1
                                break
                            else:
                                print ('uz zase?')
                                timeout(data['second'])
                                cls(data['clear'])
                        elif data['mistnost'] == 4:
                            print ('nachazi se zde pouze jedna prisera a truhla')
                            print ('co chces provest -')
                            print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                            print ('otevrit - otevrit truhlu')
                            print ('chodba - jit do tajne chodby')
                            makce = input()
                            if makce == 'boj':
                                print ('')
                                
                                bojd = [1, 1, 15, 'mys', 5]
                                data['hledat'][5] = 4
                                
                            elif makce == 'otevrit':
                                print ('je dostal jsi elixir zivota tve zivoty budou dozdraveny')
                                data['yhp'] = data['yhp']+data['rhp']
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'chodba':
                                print ('proc sem lezes kdyz zde nic nei?')
                                #int(data['penize']) = int(data['penize'])+
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'konec':
                                data['hledat'][4] = 0
                                data['hledat'][5] = 0
                                data['hledat'][0] = 1
                                break
                        elif data['mistnost'] == 5:
                            print ('protoze je toto mistnost 5 tak zde mas pouze tajnou chodbu')
                            print ('co chces provest -')
                            print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                            print ('otevrit - otevrit truhlu')
                            print ('chodba - jit do tajne chodby')
                            makce = input()
                            if makce == 'boj':
                                print ('')
                                
                                #bojd = [1, 1, 15, 'mys', 5]
                            elif makce == 'otevrit':
                                print ('hele proc to porat delas')
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'chodba':
                                print ('v chodbe je 100 penizku')
                                data['penize'] = int(data['penize'])+100
                                timeout(data['second'])
                                cls(data['clear'])
                            elif makce == 'konec':
                                data['hledat'][4] = 0
                                data['hledat'][5] = 0
                                data['hledat'][0] = 1
                                break
                            else:
                                print ('uz zase?')
                                timeout(data['second'])
                                cls(data['clear'])
                            
                        
                    while data['hledat'][5] == 4:
                        if pocet == 0:
                            bojd[0] = 10*bojd[0]
                        
                            bojd[1] = 1*bojd[1]
                            pocet = 1
                        if data['end'] == 1:
                            cls(data['clear'])
                            break
                        cls(data['clear'])
                        print ('prisera je  ' + str(bojd[3]))
                        timeout(data['second'])
                        cls(data['clear'])
                        print (str(bojd[2]) + ' toto je pocet kol')
                        timeout(data['second'])
                        
            
                        
                        cls(data['clear'])
                        for vystup in range(1, bojd[2]+1):
                            print (str(vystup) + ' toto je tvoje kolo' + '\npro utok na priseru napis B\nnebo U pro utek\naproc taky ne konec pro konec?')
                            print ('tvoje zivoty = ' + str(data['yhp']))
                            print ('zivoty prisery jsou ' + str(bojd[0]))
                            akce = input()
                            if akce == 'B':
                                print (bojd[3] + ' ma o ' + str(bojd[1]) + 'zivotu min')
                                
                                bojd[0] -= data['vm']
                                if bojd[0] <= 0:
                                    print ('vyhral jsi ale priste uvidis' + '\nziskal jsi ' + str(bojd[4]) + ' modraj')
                                    timeout(data['second'])
                                    prikaz = 3
                                    data['penize'] = int(data['penize'])+bojd[4]
                                    break
                            elif akce == 'U':
                                print ('utek se nepodaril')
                                vystup = vystup-1
                                timeout(data['second'])
                            elif akce == 'konec':
                                data['hledat'][5] = 3
                                data['end'] = 1
                                break
                            cls(data['clear'])
                            print (bojd[3] + ' ti ubrala ' + str(bojd[1]) + ' zivotu')
                            data['yhp'] -= bojd[1]
                            data['rhp'] += bojd[1]
                            data['deflect'] = data['deflect']+data['vs']*2
                            if data['deflect'] >= 51:
                                print ('jupi tuto rany jsi odvratil tvim stitem')
                                data['yhp'] += bojd[1]
                                data['rhp'] -= bojd[1]
                                data['deflect'] = 0
                                bojd[0] -= bojd[1]
                            if data['yhp'] <= 0: 
                                print ('hahaha jo ja vyhral a ty jsi prohral')
                                timeout(data['second'])
                                data['yhp'] = data['rhp']
                                data['rhp'] = 0
                                data['penize'] = 0
                                break
                            temp1 = data['vh']+data['vb']+data['vk']
                            temp = range(0, data['vh']+data['vb']+data['vk'])
                            if temp1 > 10:
                                temp = list(filter(armor, temp))
                                print (temp)
                                temp1 = 0
                                for row in temp:
                                    temp1 += 1
                                temp1 -= 1
                                print(temp1)
                                data['rhp'] -= temp1
                                data['yhp'] += temp1
                                
                            
                    
                    
                   
            cls(data['clear'])
            '''
        except Exception as e:
            print("\033[H\033[J", end="")
            print ('Nekde se stala nejaka chyba')
            print ('pokud chcete prispet k vyvoji hry tak zaslete slozku error ze slozky hry na discord server discortdiscortnamr a popis co jsi delal predtim nez se stala tato chyba')
            print('ve slozce error se nachazi soubor se savem hry a s errorem')
            print('pokud chcete skusit opravit chybu sami tak napiste error a chyba se zobrazi v tom pripade pouze poslete co jste udelali')
            print('hra se z dovodu chybi nemuze ulozi protoze pokud bi byla chyba ve slovniku data coz je jiste na 60% tak by byl vas save znicen a museli byste zacit novou hru')
            konec = input()
            if konec == 'error':
                print (e)
            elif konec == 'development':
                data = development(data, pause, timeout, cls, temp1)
            print ('ted se hra vypne')
            konec = input()
            '''
    else:
        print ('doporucuji zapnout')
        konec = input()