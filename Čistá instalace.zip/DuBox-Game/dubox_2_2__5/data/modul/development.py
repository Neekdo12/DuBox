def development(data, pause, timeout, cls, temp1):
    while True:
        cls(data['clear'])
        seznam = [1, 2, 3]
        print ('vytam te ve vyvojarskem rezimu\nseznam veci co lze delat:\nerror - ozevre nabidku na vyvolavani erroru\ndata - upravovani slovniku data\nsave - ulozit hru bez vypnuti hry\nbreakpoint - zapne breakpointy\ncls - vypne vycisteni terminalu a misto toho bude psat cls')
        akce = input()
        if akce == 'error':
            while True:
                cls(data['clear'])
                print('1)nelze delit nulou\n2)list index out of index\n3)neni definovano\nkonec - konec')
                akce = input()
                if akce == '1)':
                    ae = 0/0
                elif akce == '2)':
                    seznam[3] = 2
                elif akce == '3)':
                     if maroi == 'zizi':
                         pass
                elif akce == 'konec':
                    break
        elif akce == 'data':
                while True:
                    cls(data['clear'])
                    print ('data pro vypsani slovniku data\nnazev promene pro zmeneni jejiho obsahu')
                    akce = input()
                    if akce == 'data':
                        cls(data['clear'])
                        print (data)
                        pause()
                    elif akce == 'tutorial':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['tutorial'] = int(input())
                    elif akce == 'change_log':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['change_log'] = int(input())
                    elif akce == 'penize':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['penize'] = int(input())
                    elif akce == 'vm':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['vm'] = int(input())
                    elif akce == 'vs':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['vs'] = int(input())
                    elif akce == 'rhp':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['rhp'] = int(input())
                    elif akce == 'yhp':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['yhp'] = int(input())
                    elif akce == 'cenam':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['cenam'] = int(input())
                    elif akce == 'cenas':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['cenas'] = int(input())
                    elif akce == 'mistnost':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['mistnost'] = int(input())
                    elif akce == 'deflect':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['deflect'] = int(input())
                    elif akce == 'cenah':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['cenah'] = int(input())
                    elif akce == 'cenab':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['cenab'] = int(input())
                    elif akce == 'cenak':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['cenak'] = int(input())
                    elif akce == 'vh':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['vh'] = int(input())
                    elif akce == 'vb':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['vb'] = int(input())
                    elif akce == 'vk':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['vk'] = int(input())
                    elif akce == 'endp':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['endp'] = int(input())
                    elif akce == 'end':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['end'] = int(input())
                    elif akce == 'second':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['second'] = int(input())
                    elif akce == 'devel':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['devel'] = int(input())
                    elif akce == 'akce':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['akce'] = int(input())
                    elif akce == 'pasword':
                        cls(data['clear'])
                        print ('predpokladam predpokladam string')
                        data['pasword'] = input()
                    elif akce == 'clear':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['clear'] = int(input())
                    elif akce == 'pdi':
                        cls(data['clear'])
                        print ('predpokladam cislo')
                        data['pdi'] = int(input())
                    elif akce == 'konec':
                        break
        elif akce == 'save':
            import csv
            with open('position/' + temp1, mode='w') as employee_file:
                employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        
                employee_writer.writerow([str(data['tutorial']), str(data['change_log']), str(data['penize']), str(data['vm']), str(data['vs']), str(data['rhp']), str(data['yhp']), str(data['cenam']), str(data['cenas']), str(data['mistnost']), str(data['deflect']), str(data['cenah']), str(data['cenab']), str(data['cenak']), str(data['vh']), str(data['vb']), str(data['vk']), str(data['second']), str(data['devel']), str(data['pasword'])])
        elif akce == 'cls':
            if data['clear'] == 1:
                data['clear'] = 0
            else:
                data['clear'] = 1
            pause()
        elif akce == 'breakpoint':
            if data['pdi'] == 0:
                data['pdi'] = 1
            else:
                data['dpd'] = 0
        elif akce == 'konec':
            return data
                