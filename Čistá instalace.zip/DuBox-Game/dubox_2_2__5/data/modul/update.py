def update(pause, cls, data, ver, text):
    c = data['clear']
    #uvodni text
    text(f'Vyta te instalator DuBoxu verze {ver}')
    text('prosim kdo nerozumi pythonu prectite si tutorial v DuBoxu\npokud nemate nainszalovany DuBox tutorial se take nachazi v readme.txt')
    cls(c)
    #seznam akci
    while True:
        print('instalace - nainstaluje DuBox (nelze preinstalovat nainstalovany DuBox)\nobnoveni - obnovi data do stavu po instalaci (doporucuji nejdrave udelat zalohu)\nzaloha - soubor se zalohou DuBoxu\nnahraz zalohu - nahraje zalohu do DuBoxu\nvytvoreni aktualizacniho souboru - vytvori soubor ktery nahrajete do nove verze DuBoxu\n verze - zobrazi kompatybilni verze s kterymi lze tuto verzi aktualizovat')
        akce = input()
        
        #porovnavani zadanych akci
        if akce == 'instalace':
            cls(c)
            print ('prosim vyber si verzi:')
            print ('2.2..5 (doporucene)\n2.1..5\n2..5\n1.1.1..5\n1.1..5\n1.0.1..5\n1.0..5')
            akce = input()
            
            if akce == '2.2..5':
                
    