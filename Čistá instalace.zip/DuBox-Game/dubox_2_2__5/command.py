import datetime
import time

def cls(clear):
    if clear == 1:
        print("\033[H\033[J", end="")
    else:
        print ('cls')
def timeout(second):
    if second == 'pause':
        konec = input()
    else:
        time.sleep(second)
def pause():
    konec = input()
def armor(temp):
    return temp%10 == 0
def pdi(temp):
    if temp == 1:
        breakpoint()
def learnig(text, word):
    while True:
        print("\033[H\033[J", end="")
        print (text)
        akce = input()
        if akce == word:
            print("\033[H\033[J", end="")
            print ('jen tak dal')
            input()
            return 1
        else:
            print("\033[H\033[J", end="")
            print ('nauc se prosim psat')
            input()
def text(text):
    print("\033[H\033[J", end="")
    print(text)
    input()