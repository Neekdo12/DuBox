while True:
    with open('firs_instal_data.txt', 'r') as data:
         first_run = data.readline()
    #print(first_run) 
    c = 1
    
    #import knihoven
    from imodul.instal import *
    #from imodul.update import *
    from imodul.command import *
    import random
    import datetime
    import csv
    
    #zacatek duboxu
    if first_run == '0':
        
        #pokud hru spoustite poprve tak zapne instalaci
        instal(pause, cls, c, text, timeout)
    elif first_run == '1':
        
        #pokud jste jiz hru nainstalovali tak vyhleda verzi instalace
        with open('ver_run.txt', 'r') as file:
            ver_run = file.readlines()
        #print (ver_run)
        
        for row in range(0, 5):
            print('loading' + '.' * row)
            timeout(1)
            cls(c)
            
        print ('zmacky enter pro nacteni hry')
        akce = input()
        
        if akce == 'reinstal':
            instal(pause, cls, c, text, timeout)
            break
        
        
        
        if ver_run == ['dva_dva__pet']:
            #pokud mate verzi 2.2..5 spusti tuto verzi i se vsemi moduli
            from dubox_2_2__5.dubox import *
            from dubox_2_2__5.data.modul.tutorial import *
            from dubox_2_2__5.data.modul.date_manage import *
            from dubox_2_2__5.data.modul.change_log import *
            from dubox_2_2__5.data.modul.development import *
            from dubox_2_2__5.command import *
            end = dubox(csv, cls, pdi, timeout, text, random, learnig, tutoriall, pause, datemanagee, change_log, development)
            if end == 1:
                break
            else:
                from imodul.update import *
        elif ver_run == ['dva_jedna__pet']:
            #pokud mate nainstalovanou verzi 2.1..5 tak ji to spusti
            from DuBox_2_1__5.dubox import *
            from DuBox_2_1__5.data.date_manage import *
            from DuBox_2_1__5.data.development import *
            from DuBox_2_1__5.command import *
            game(datemanagee, csv, pause, cls, timeout,datetime, development,  random, pdi)
            break
        elif ver_run == ['dva__pet']:
            from DuBox_2__5.command import *
            from DuBox_2__5.dubox import *
            from DuBox_2__5.command import *
            break
        elif ver_run == ['jedna_jedna_jedna__pet']:
            #from DuBox_1_1_1__5.command import *
            from DuBox_1_1_1__5.dubox import *
        elif ver_run == ['jedna_jedna__pet']:
            #print ('hh')
            from DuBox_1_1__5.dubox import *
            break
        elif ver_run == ['jedna_nula_jedna__pet']:
            from DuBox_1_0_1__5.dubox import *
            break
        elif ver_run == ['jedna_nula__pet']:
            from DuBox_1_0__5.dubox import *
            break
        else:
            print('nepodporovana verze')
            pause()
    
    
    elif first_run == '2':
        pass