        DuBox-Game
    Prvni instalace
1) Spustt soubor DuBox pres pydroid
2) Pockej az se zapne
3) Vyber si verzi
4) Hra se restartuje
5) Hra se nacte
6) Uzi jsi tvou vybranou verzi
    Zmena verze
1) Pokud mate verzi starsi verzi nes 2.2..5 tK prejdite k roku 6)
2) Ve hre napistedo policka akce update a vyberte obnoveni
3) hra se vypne
4) zapni hru a vyber si verzi
6) starsi verze:
7) Otevri slozku hry v pruzkumniku souboru
8) Otevri soubor firs_instal_data
9) jeho obsach prepis na 0
10) soubor uloz a zapni hru