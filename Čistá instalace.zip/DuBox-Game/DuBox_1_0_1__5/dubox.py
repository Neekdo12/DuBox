
def cls():
    print("\033[H\033[J", end="")
def pause():
    komec = input()



tutorial = 0

if tutorial == 1:
    cls = cls()
    print ('ahoj vitej ve hre dungen')
    pause()
    pokus = 'false'
    pocet = 0
    cls()
    print ('ted vas hra dungen provede tutorialem')
    pause()
    cls()
    print ('napis dalsi pro vstup do prvni mistnoati')

    while 1 == 1:
        akce = input()
        if akce == 'dalsi':
            print ('vyborne')
            pause()
            break
        else:
            print ('chyba napis to znovu')
    cls()
    while 1 == 1:
        print ('napis zpet pro navrat do predesle  mistnosti')
        akce = input()
        if akce == 'zpet':
            print ('vyborne')
            pause()
            break
        else:
            print ('chyba napis to znovu')
            pause()
        cls()
    cls()
    while 1 == 1:
        print ('napis prohledat pro prohledani dungnu')
        akce = input()
        if akce == 'prohledat':
            print ('vyborne')
            pause()
            break
        else:
            print ('chyba skuz to znovu')
            kone = input()
        cls()
    cls()
    while 1 == 1:
        print ('napis napoveda pro zobrazeni napovjedy ')
        akce = input()
        if akce == 'napoveda':
            print ('vyborne')
            pause()
            break
        else:
            print ('chyba zkus to znovu')
            pause()
        cls()
    cls()
    while 1 == 1:
        print ('napis obchod pro otevreni obchodu')
        akce = input()
        if akce == 'obchod':
            print ('vyborne')
            pause()
            break
        else:
            print ('proc to teda hrajes kdys neumis psat')
            pause()
        cls()
    cls()
    while 1 == 1:
        print ('napis inventar pro otevreni inventare')
        akce = input()
        if akce == 'inventar':
            print ('koukni ze umis psat')
            pause()
            break
        else:
            print ('tak to radsi vypni a di se ucit cestinu')
            pause()
        cls()
    cls()
    while 1 ==1:
        print ('napis seznam pro zobrazeni veci ktere si muzes koupit')
        akce = input()
        if akce == 'seznam':
            print ('nebo tam ani nemusis a nauc se psat')
            pause()
            break
        else:
            print ('pokut neumis psat tak koukni do kodu hry a text si zkopiruj!')
            pause()
        cls()
    cls()
    while 1 ==1:
        print ('napis penezenka pro zobrezeni poctu tvych financi')
        akce = input()
        if akce == 'penezenka':
            print ('konecne normalni clovek co umi psat')
            pause()
            break
        else:
            print ('hele uz me to nebavi tak tu hru vypni a posli ji nekomu dalsimu o kom vis ze umi dobre opisovat!!!!!!')
            pause()
        cls()
    cls()
    while 1 ==1:
        print ('napis nakup pro nakoupeni veci v obchode')
        akce = input()
        if akce == 'nakup':
            print ('ty ty jsi inteligentnejsi nez ty dva predtim dohromady!')
            pause()
            break
        else:
            print ('ty jsi uplne stejny tupec jako ten predchozi clovek!!!')
            pause()
        cls()
    cls()
    while 1 ==1:
        print ('napis konec pro navrat do hry a pokud budes ve hre tak vypne a ulozi hru')
        akce = input()
        if akce == 'konec':
            print ('jen tak dal')
            pause()
            break
        else:
            print ('jeste parkrat a budes tenhle tutorial delat znova')
            pocet = pocet+1
            if pocet == 2:
                pokus = 'true'
            pause()
        cls()
    cls()
    print ('pribeh')
    if pokus == 'true':
        while 1 == 1:
            print ('error')
            pause()
            cls()
    pause()
    cls()









#definyce nejakych promenych

inventar = 0
obchod = 0
napoveda = 0
otazka = 1
penize = 50
vm = 1
cenam = 50
cenas = 100
vs = 0
mistnost = 1
yhp = 15
rhp = 0
end = 0
change_log = 1
deflect = 0
while 1 == 1:
    if change_log == 1:
        cls()
        print ('change log:\n\n\nin dev version:\n\n1..5 - vydani prvni nudne verze hry\n\n1.0.1..5 - opravy:\nkdyz jste porazeli priseru tak pokut jste ji porazeli silou mece ktera nemela v nasobilce 10 tak se prisera neporazila a zivoty sli do minusu\nstit nefungoval\nzatim konec\nzmeny v kodu:\npro vymazani textu a pockani na zmacknuti entru jsou pouzivany funkce\noptimalizace kodu na bojovani\nzmeny:\ndo obchod byli pridany dve polzky: dozdravi a zivot\nbyl pridan change log')
        change_log = 0
        pause()
        
    while otazka == 1:
        cls()
        print ('napis akci kterou chces provist')
        print ('nebo napis napoveda pro zobrazeni napovedy')
        akce = input()
        if akce == 'obchod':
            otazka = 0
            obchod = 'obchod'
        elif akce == 'inventar':
            inventar = 'inventar'
            otazka = 0
        elif akce == 'napoveda':
            otazka = 0
            napoveda = 'napoveda'
        elif akce == 'dalsi':
            otazka = 0
            mapa = 'mapa'
            prikaz = 1
        elif akce == 'zpet':
            otazka = 0
            mapa = 'mapa'
            prikaz = 2
        elif akce == 'prohledat':
            otazka = 0
            mapa = 'mapa'
            prikaz = 3
        elif akce == 'mistnost':
            print (mistnost)
            pause()
        else:
            print ('chybny text')
            pause()
            
            #obchod
            
        while obchod == 'obchod':
            
            #zeptani se na akci
            
            otazka = 1
            cls()
            print ('napis co chces provest v obchode')
            print ('nebo napoveda pro zobrazeni napovedy')
            akce = input()
            
            #kod ktery zapne kod ktery jste si vybrali
            
            if akce == 'seznam':
                
                #vypise co se da koupit a cenu
                
                cls()
                print ('vylepseni mece - ' + str(cenam) + ' modraj')
                
                
                print('')
                print ('vylepseni stitu - ' + str(cenas) + ' modraj')
                
                
                print ('')
                print ('dozdravit - 5 modraj')
                print ()
                print ('zivot - 50 modraj')
                print()
                print ('pokud chcez zjistit co jake vylepseni dela napis podrobnosti a v \ndalsim textovem poli nazev vylepseni')
                akce = input() 
                if akce == 'podrobnosti':
                    akce = input()
                    if akce == 'vylepseni mece':
                        cls()
                        print ('z kazdym jedni levelem se zvisi poskozeni zbrani s nazvem mec')
                        
                        pause()
                    elif akce == 'vylepseni stitu':
                        cls()
                        print ('kazdy jeden level prida sanci 2% na vyhnuti se utoku priser. maximalni procento je 50')
                        pause()
                    elif akce == 'dozdravit':
                        cls()
                        print ('dozdracu tve zivoty')
                        pause()
                    elif akce == 'zivot':
                        cls()
                        print ('da ti 15 zivotu na vic a dozdravi te')
                        
                        pause()
                    else:
                        print ('cybny text')
                        pause()
                    
                    
            elif akce == 'nakup':
                
                #zepta se na to co chcete koupit
                
                cls()
                print ('co chcete koupit?')
                nakup = input()
                
                #koupi vase zadane vylepseni
                
                if nakup == 'vylepseni mece':
                    if penize >= cenam:
                        
                        #zkonrroluke jestli mate dostatek penez a pricte silu mece
                        
                        penize = penize - cenam
                        vm = vm + 1
                        cenam = cenam * 2
                        cls()
                        print ('vylepseni koupeno')
                        pause()
                        
                        
                        
                elif nakup == 'vylepseni stitu':
                    if penize >= cenas:
                        penize = penize - cenas
                        cls()
                        print ('vylepseni koupeno')
                        vs = vs + 1
                        pause()
                    else:
                        cls()
                        print ('nedostatek penez')
                        pause()
                        
                elif nakup == 'dozdravit':
                    if penize >= 5:
                        penize = penize - 1
                        cls()
                        print ('byl jsi dozdraven')
                        yhp = yhp+rhp
                        rhp = 0
                        pause()
                        
                    else:
                        cls()
                        print ('nedostatek penez')
                        pause()
                        
                elif nakup == 'zivot':
                    if penize >= 50:
                        penize = penize - 50
                        cls()
                        print ('srdce koupeno')
                        yhp = yhp+rhp+15
                        rhp = 0
                        pause()
                            
                            
                        
                        
                        #vypsani nedostatku penez a chyba v napsanem textu
                        
                    else:
                        cls()
                        print ('nedostatek penez')
                        pause()
                
                else:
                    cls()
                    print ('toto vylepseni neexistuje')
                    pause()
            elif akce == 'penezenka':
                cls()
                print (penize)
                pause()
            elif akce == 'konec':
                otazka = 1
                obchod = 0
                
            else:
                cls()
                print ('cybny text')
                pause()
        while inventar == 'inventar':
            
            #inventar
            
            cls()
            print (vm)
            print ('sila mece')
            print ('')
            print (vs)
            print ('sila stitu')
            print ('')
            print (penize)
            print ('penize')
            print ()
            print (yhp)
            print ('zivoty')
            pause()
            
            inventar = 0
            otazka = 1
            break
        cls()
        while napoveda == 'napoveda':
            print ('dalsi - dalsi mistnost')
            print ('zpet - predhozi mistnost')
            print ('prohledat - pro prohledani mistnoati')
            print ('obchod - otevreni obchodu')
            print ('inventar - pro otevreni inventare')
            print ('seznam - pro otevreni nakupniho seznamu (pouze v obchode)')
            print ('penezenka - pro zobrazeni tvich penez (pouze v obchode)')
            print ('nakup - proved nakup (pouze v obchode)')
            print ('konec - pro vraceni do hry a pokud uz vni jste tak ukonci a vypne hru')
            print ('mistnost - zobrazi mistnost ve ktere se nachazis')
            pause()
            otazka = 1
            napoveda =0
    
        
    while mapa == 'mapa':
        while prikaz == 1:
            mistnost = mistnost+1
            if mistnost == 6:
                print ('konecna mistnost')
                pause()
                mistnost = mistnost-1
            prikaz = 0
            mapa = 0
            otazka = 1
        
        while prikaz == 2:
            mistnost = mistnost-1
            if mistnost == 0:
                print ('jsi na zacatku')
                pause()
                mistnost = mistnost+1
            prikaz = 0
            mapa = 0
            otazka = 1
        cls()
        
        while prikaz == 3:
            pocet = 0
            end = 0
            if mistnost == 1:
                cls()
                print ('v mistnosti se nachazi 1 bedna')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('v mistnosti se nenachazi prisery')
                    
                    #bojd = [1, 1, 15, 'mys', 5]
                elif makce == 'otevrit':
                    cls()
                    print ('v bedne se nachazi elixir zivot')
                    pause()
                    cls()
                    print ('najedno sis vsiml ze nemas srdce a ze se take zmenilo v krabici nastesti si na posledni chvili stihl vypit lektvar zivota a veskere rany magii utrpene se zacelili.')
                    pause()
                elif makce == 'chodba':
                    print ('zde neni zadna tajna chodba')
                    pause()
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    pause()
            elif mistnost == 2:
                print ('v mistnosti je 1 prisera')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    bojd = [1, 1, 15, 'mys', 5]
                    prikaz = 4
                elif makce == 'otevrit':
                    print ('zde neni zadna bedna ale treba jinde bude')
                    pause()
                    cls()
                elif makce == 'chodba':
                    print ('je zde jen otvor zasipany suti')
                    #penize = penize+
                    pause()
                    cls()
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    pause()
                    cls()
            elif mistnost == 3:
                print ('je tady je ve stene dira a vni se neco leskne. jestli pak to nebude tajna hodba!')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    #bojd = [1, 1, 15, 'mys', 5]
                elif makce == 'otevrit':
                    print ('neni to bedna ale chodba')
                    pause()
                    cls()
                elif makce == 'chodba':
                    print ('jej nasel jsi 50 modraj ted si muzes neco koupit')
                    penize = penize+50
                    pause()
                    cls()
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    pause()
                    cls()
            elif mistnost == 4:
                print ('nachazi se zde pouze jedna prisera a truhla')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    bojd = [1, 1, 15, 'mys', 5]
                    prikaz = 4
                    print (list(kolo))
                elif makce == 'otevrit':
                    print ('je dostal jsi elixir zivota tve zivoty budou dozdraveny')
                    yhp = yhp+rhp
                    pause()
                    cls()
                elif makce == 'chodba':
                    print ('proc sem lezes kdyz zde nic nei?')
                    #penize = penize+
                    pause()
                    cls()
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
            elif mistnost == 5:
                print ('protoze je toto mistnost 5 tak zde mas pouze tajnou chodbu')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    #bojd = [1, 1, 15, 'mys', 5]
                elif makce == 'otevrit':
                    print ('hele proc to porat delas')
                    pause()
                    cls()
                elif makce == 'chodba':
                    print ('v chodbe je 100 penizku')
                    penize = penize+100
                    pause()
                    cls()
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    pause()
                    cls()
                
            
        while prikaz == 4:
            if pocet == 0:
                bojd[0] = 10*bojd[0]
            
                bojd[1] = 1*bojd[1]
                pocet = 1
            if end == 1:
                cls()
                break
            cls()
            print ('prisera je  ' + str(bojd[3]))
            pause()
            cls()
            print (str(bojd[2]) + ' toto je pocet kol')
            pause()
            

            
            cls()
            for vystup in range(1, bojd[2]+1):
                print (str(vystup) + ' toto je tvoje kolo' + '\npro utok na priseru napis B\nnebo U pro utek\naproc taky ne K pro konec?')
                print ('tvoje zivoty = ' + str(yhp))
                print ('zivoty prisery jsou ' + str(bojd[0]))
                akce = input()
                if akce == 'B':
                    print (bojd[3] + ' ma o ' + str(bojd[1]) + 'zivotu min')
                    
                    bojd[0] -= vm
                    if bojd[0] <= 0:
                        print ('vyhral jsi ale priste uvidis' + '\nziskal jsi ' + str(bojd[4]) + ' modraj')
                        pause()
                        prikaz = 3
                        penize = penize+bojd[4]
                        break
                elif akce == 'U':
                    print ('utek se nepodaril')
                    vystup = vystup-1
                    pause()
                elif akce == 'K':
                    prikaz = 3
                    end = 1
                    break
                cls()
                print (bojd[3] + ' ti ubrala ' + str(bojd[1]) + ' zivotu')
                yhp -= bojd[1]
                rhp += bojd[1]
                deflect = deflect+vs
                if deflect >= 51:
                    print ('jupi tuto rany jsi odvratil tvim stitem')
                    yhp += bojd[1]
                    rhp -= bojd[1]
                    deflect = 0
                    bojd[0] -= bojd[1]
                if yhp == 0: 
                    print ('hahaha jo ja vyhral a ty jsi prohral')
                    pause()
                    yhp = rhp
                    rhp = 0
                    penize = 0
                    break
        
        
       
          
cls()
        