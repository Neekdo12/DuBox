
tutorial = 0

if tutorial == 1:
    cls = print("\033[H\033[J", end="")
    print ('ahoj vitej ve hre dungen')
    konec = input()
    pokus = 'false'
    pocet = 0
    print("\033[H\033[J", end="")
    print ('ted vas hra dungen provede tutorialem')
    konec = input()
    print("\033[H\033[J", end="")
    print ('napis dalsi pro vstup do prvni mistnoati')

    while 1 == 1:
        akce = input()
        if akce == 'dalsi':
            print ('vyborne')
            konec = input()
            break
        else:
            print ('chyba napis to znovu')
    print("\033[H\033[J", end="")
    while 1 == 1:
        print ('napis zpet pro navrat do predesle  mistnosti')
        akce = input()
        if akce == 'zpet':
            print ('vyborne')
            konec = input()
            break
        else:
            print ('chyba napis to znovu')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 == 1:
        print ('napis prohledat pro prohledani dungnu')
        akce = input()
        if akce == 'prohledat':
            print ('vyborne')
            konec = input()
            break
        else:
            print ('chyba skuz to znovu')
            kone = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 == 1:
        print ('napis napoveda pro zobrazeni napovjedy ')
        akce = input()
        if akce == 'napoveda':
            print ('vyborne')
            konec = input()
            break
        else:
            print ('chyba zkus to znovu')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 == 1:
        print ('napis obchod pro otevreni obchodu')
        akce = input()
        if akce == 'obchod':
            print ('vyborne')
            konec = input()
            break
        else:
            print ('proc to teda hrajes kdys neumis psat')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 == 1:
        print ('napis inventar pro otevreni inventare')
        akce = input()
        if akce == 'inventar':
            print ('koukni ze umis psat')
            konec = input()
            break
        else:
            print ('tak to radsi vypni a di se ucit cestinu')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 ==1:
        print ('napis seznam pro zobrazeni veci ktere si muzes koupit')
        akce = input()
        if akce == 'seznam':
            print ('nebo tam ani nemusis a nauc se psat')
            konec = input()
            break
        else:
            print ('pokut neumis psat tak koukni do kodu hry a text si zkopiruj!')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 ==1:
        print ('napis penezenka pro zobrezeni poctu tvych financi')
        akce = input()
        if akce == 'penezenka':
            print ('konecne normalni clovek co umi psat')
            konec = input()
            break
        else:
            print ('hele uz me to nebavi tak tu hru vypni a posli ji nekomu dalsimu o kom vis ze umi dobre opisovat!!!!!!')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 ==1:
        print ('napis nakup pro nakoupeni veci v obchode')
        akce = input()
        if akce == 'nakup':
            print ('ty ty jsi inteligentnejsi nez ty dva predtim dohromady!')
            konec = input()
            break
        else:
            print ('ty jsi uplne stejny tupec jako ten predchozi clovek!!!')
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    while 1 ==1:
        print ('napis konec pro navrat do hry a pokud budes ve hre tak vypne a ulozi hru')
        akce = input()
        if akce == 'konec':
            print ('jen tak dal')
            konec = input()
            break
        else:
            print ('jeste parkrat a budes tenhle tutorial delat znova')
            pocet = pocet+1
            if pocet == 2:
                pokus = 'true'
            konec = input()
        print("\033[H\033[J", end="")
    print("\033[H\033[J", end="")
    print ('pribeh')
    if pokus == 'true':
        while 1 == 1:
            print ('error')
            konec = input()
            print("\033[H\033[J", end="")
    konec = input()
    print("\033[H\033[J", end="")

    print ('zatim konec')








#definyce nejakych promenych

inventar = 0
obchod = 0
napoveda = 0
otazka = 1
penize = 50
vm = 1
cenam = 50
cenas = 100
vs = 0
mistnost = 2
yhp = 15
rhp = 0
end = 0
while 1 == 1:
    while otazka == 1:
        print("\033[H\033[J", end="")
        print ('napis akci kterou chces provist')
        print ('nebo napis napoveda pro zobrazeni napovedy')
        akce = input()
        if akce == 'obchod':
            otazka = 0
            obchod = 'obchod'
        elif akce == 'inventar':
            inventar = 'inventar'
            otazka = 0
        elif akce == 'napoveda':
            otazka = 0
            napoveda = 'napoveda'
        elif akce == 'dalsi':
            otazka = 0
            mapa = 'mapa'
            prikaz = 1
        elif akce == 'zpet':
            otazka = 0
            mapa = 'mapa'
            prikaz = 2
        elif akce == 'prohledat':
            otazka = 0
            mapa = 'mapa'
            prikaz = 3
        elif akce == 'mistnost':
            print (mistnost)
            konec = input()
        else:
            print ('chybny text')
            konec = input()
            
            #obchod
            
        while obchod == 'obchod':
            
            #zeptani se na akci
            
            otazka = 1
            print("\033[H\033[J", end="")
            print ('napis co chces provest v obchode')
            print ('nebo napoveda pro zobrazeni napovedy')
            akce = input()
            
            #kod ktery zapne kod ktery jste si vybrali
            
            if akce == 'seznam':
                
                #vypise co se da koupit a cenu
                
                print("\033[H\033[J", end="")
                print ('vylepseni mece - ' + str(cenam) + ' modraj')
                
                
                print('')
                print ('vylepseni stitu - ' + str(cenas) + ' modraj')
                
                
                print ('')
                print ('pokud chcez zjist co jake vylepseni dela napis podrobnosti a v \ndalsim textovem poli nazev vylepseni')
                akce = input() 
                if akce == 'podrobnosti':
                    akce = input()
                    if akce == 'vylepseni mece':
                        print("\033[H\033[J", end="")
                        print ('z kazdym jedni levelem se zvisi poskozeni zbrani s nazvem mec')
                        
                        konec = input()
                    elif akce == 'vylepseni stitu':
                        print("\033[H\033[J", end="")
                        print ('kazdy jeden level prida sanci 2% na vyhnuti se utoku priser. maximalni procento je 50')
                        
                        konec = input()
                    else:
                        print ('cybny text')
                        konec = input()
                    
                    
            elif akce == 'nakup':
                
                #zepta se na to co chcete koupit
                
                print("\033[H\033[J", end="")
                print ('co chcete koupit?')
                nakup = input()
                
                #koupi vase zadane vylepseni
                
                if nakup == 'vylepseni mece':
                    if penize >= cenam:
                        
                        #zkonrroluke jestli mate dostatek penez a pricte silu mece
                        
                        penize = penize - cenam
                        vm = vm + 1
                        cenam = cenam * 2
                        print("\033[H\033[J", end="")
                        print ('vylepseni koupeno')
                        konec = input()
                        
                        
                        
                elif nakup == 'vylepseni stitu':
                    if penize >= cenas:
                        penize = penize - cenas
                        print("\033[H\033[J", end="")
                        print ('vylepseni koupeno')
                        vs = vs + 1
                        konec = input()
                            
                        
                        
                        #vypsani nedostatku penez a chyba v napsanem textu
                        
                    else:
                        print("\033[H\033[J", end="")
                        print ('nedostatek penez')
                        konec = input()
                
                else:
                    print("\033[H\033[J", end="")
                    print ('toto vylepseni neexistuje')
                    konec = input()
            elif akce == 'penezenka':
                print("\033[H\033[J", end="")
                print (penize)
                konec = input()
            elif akce == 'konec':
                otazka = 1
                obchod = 0
                
            else:
                print("\033[H\033[J", end="")
                print ('cybny text')
                konec = input()
        while inventar == 'inventar':
            
            #inventar
            
            print("\033[H\033[J", end="")
            print (vm)
            print ('sila mece')
            print ('')
            print (vs)
            print ('sila stitu')
            print ('')
            print (penize)
            print ('penize')
            konec = input()
            
            inventar = 0
            otazka = 1
            break
        print("\033[H\033[J", end="")
        while napoveda == 'napoveda':
            print ('dalsi - dalsi mistnost')
            print ('zpet - predhozi mistnost')
            print ('prohledat - pro prohledani mistnoati')
            print ('obchod - otevreni obchodu')
            print ('inventar - pro otevreni inventare')
            print ('seznam - pro otevreni nakupniho seznamu (pouze v obchode)')
            print ('penezenka - pro zobrazeni tvich penez (pouze v obchode)')
            print ('nakup - proved nakup (pouze v obchode)')
            print ('konec - pro vraceni do hry a pokud uz vni jste tak ukonci a vypne hru')
            print ('mistnost - zobrazi mistnost ve ktere se nachazis')
            konec = input()
            otazka = 1
            napoveda =0
    
        
    while mapa == 'mapa':
        while prikaz == 1:
            mistnost = mistnost+1
            if mistnost == 6:
                print ('konecna mistnost')
                konec = input()
                mistnost = mistnost-1
            prikaz = 0
            mapa = 0
            otazka = 1
        
        while prikaz == 2:
            mistnost = mistnost-1
            if mistnost == 0:
                print ('jsi na zacatku')
                konec = input()
                mistnost = mistnost+1
            prikaz = 0
            mapa = 0
            otazka = 1
        print("\033[H\033[J", end="")
        
        while prikaz == 3:
            if mistnost == 1:
                print ('v mistnosti se nachazi 1 bedna')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('v mistnosti se nenachazi prisery')
                    
                    #prisera = 'mys'
                    #prikaz = 4
                    #hp = 1
                    #dm = 1
                    #loot = 5
                    #kolo = range(1, 13)
                    #print (list(kolo))
                    #konec = input()
                elif makce == 'otevrit':
                    print("\033[H\033[J", end="")
                    print ('v bedne se nachazi elixir zivot')
                    konec = input()
                    print("\033[H\033[J", end="")
                    print ('najedno sis vsiml ze nemas srdce a ze se take zmenilo v krabici nastesti si na posledni chvili stihl vypit lektvar zivota a veskere rany magii utrpene se zacelili.')
                    konec = input()
                elif makce == 'chodba':
                    print ('zde neni zadna tajna chodba')
                    konec = input()
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    konec = input()
            elif mistnost == 2:
                print ('v mistnosti je 1 prisera')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    prisera = 'mys'
                    prikaz = 4
                    hp = 1
                    dm = 1
                    loot = 5
                    kolo = range(1, 16)
                elif makce == 'otevrit':
                    print ('zde neni zadna bedna ale treba jinde bude')
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'chodba':
                    print ('je zde jen otvor zasipany suti')
                    #penize = penize+
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    konec = input()
                    print("\033[H\033[J", end="")
            elif mistnost == 3:
                print ('je tady je ve stene dira a vni se neco leskne. jestli pak to nebude tajna hodba!')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    #prisera = 'mys'        #list
                    #prikaz = 4
                    #hp = 1
                    #dm = 1
                    #loot = 5
                    #kolo = range(1, 13)
                    #print (list(kolo))
                elif makce == 'otevrit':
                    print ('neni to bedna ale chodba')
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'chodba':
                    print ('jej nasel jsi 50 modraj det si muzes neco koupit')
                    penize = penize+50
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    konec = input()
                    print("\033[H\033[J", end="")
            elif mistnost == 4:
                print ('nachazi se zde pouze jedna prisera a truhla')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    prisera = 'krysa'        #list
                    prikaz = 4
                    hp = 1
                    dm = 2
                    loot = 15
                    kolo = range(1, 13)
                    end = 0
                    print (list(kolo))
                elif makce == 'otevrit':
                    print ('je dostal jsi elixir zivota tve zivoty budou dozdraveny')
                    yhp = yhp+rhp
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'chodba':
                    print ('proc sem lezes kdyz zde nic nei?')
                    #penize = penize+
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
            elif mistnost == 5:
                print ('protoze je toto mistnost 5 tak zde mas pouze tajnou chodbu')
                print ('co chces provest -')
                print ('boj - zautocit na nepratele (nekdy si te muzou vsimnout rovnou po pruzkumu)')
                print ('otevrit - otevrit truhlu')
                print ('chodba - jit do tajne chodby')
                makce = input()
                if makce == 'boj':
                    print ('')
                    
                    #prisera = 'mys'        #list
                    #prikaz = 4
                    #hp = 1
                    #dm = 1
                    #loot = 5
                    #kolo = range(1, 13)
                    #print (list(kolo))
                elif makce == 'otevrit':
                    print ('hele proc to pprat delas')
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'chodba':
                    print ('v chodbe je 100 penizku')
                    penize = penize+100
                    konec = input()
                    print("\033[H\033[J", end="")
                elif makce == 'konec':
                    mapa = 0
                    prikaz = 0
                    otazka = 1
                    break
                else:
                    print ('uz zase?')
                    konec = input()
                    print("\033[H\033[J", end="")
                
            
        while prikaz == 4:
            if end == 1:
                break
            print("\033[H\033[J", end="")
            #print ('ted te provedu tutorialem v boji jako brvni ti vzdy hra napise z jakpu priserou bojujes')
            print ('prisera je  ' + prisera)
            konec = input()
            print("\033[H\033[J", end="")
           # print ('pokazde ti hra napise kolik budes mit na souboj kol a \nv kolikatem si')
            print (str(list(kolo)) + ' toto je pocet kol')
            konec = input()
            zivot = 10
            zivot = zivot*hp
            utok = 1
            utok = utok*dm
            
            print("\033[H\033[J", end="")
            for vystup in kolo:
                print (str(vystup) + ' toto je tvoje kolo')
                print ('pro utok na priseru napis B\nnebo U pro utek\naproc taky ne K pro konec?')
                print ('tvoje zivoty = ' + str(yhp))
                print ('zivoty prisery jsou' + str(zivot))
                akce = input()
                if akce == 'B':
                    print (prisera + ' ma o ' + str(vm) + ' zivotu min')
                    
                    zivot = zivot-vm
                    if zivot == 0:
                        print ('vyhral jsi ale priste uvidis')
                        print ('ziskal jsi ' + str(loot) + ' modraj')
                        konec = input()
                        prikaz = 3
                        penize = penize+loot
                        break
                elif akce == 'U':
                    print ('utek se nepodaril')
                    vystup = vystup-1
                    konec = input()
                elif akce == 'K':
                    prikaz = 3
                    end = 1
                    break
                print("\033[H\033[J", end="")
                print (prisera + ' ti ubrala ' + str(utok) + 'zivotu')
                yhp = yhp-utok
                rhp = rhp+utok
                if yhp == 0: 
                    print ('hahaha jo ja vyhral a ty jsi prohral')
                    konec = input()
                    yhp = rhp
                    rhp = 0
                    break
        
        
       
          
print("\033[H\033[J", end="")
        